import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('foodhub_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('foodhub_token');
      localStorage.removeItem('foodhub_user');
      window.dispatchEvent(new Event('foodhub-auth-expired'));
    }
    return Promise.reject(error);
  }
);

export const pageContent = (data) => data?.content || [];

export const errorMessage = (error) =>
  error.response?.data?.message || error.message || 'Something went wrong';

export default api;
